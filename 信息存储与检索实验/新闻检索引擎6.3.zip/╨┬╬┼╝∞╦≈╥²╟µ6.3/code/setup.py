
from spider import get_news_pool, crawl_news
from index_module import IndexModule
from recommendation_module import RecommendationModule
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import configparser

def get_max_page(root):
    response = requests.get(root)
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    # 使用 string 参数替换 text 参数
    script_tag = soup.find('script', string=lambda t: 'maxPage' in (t or ''))
    if script_tag:
        script = script_tag.string
        start_index = script.find('var maxPage =')
        if start_index != -1:
            end_index = script.find(';', start_index)
            max_page_str = script[start_index:end_index].split('=')[1].strip()
            max_page = int(max_page_str)
            return max_page
    return None


def crawling():
    print('-----start crawling time: %s----- ' %datetime(2024,5,31))
    config = configparser.ConfigParser()
    config.read('../config.ini', 'utf-8')
    root = 'https://www.sohu.com/?pvid=b6a6473ea63069a1'
    max_page = get_max_page(root + '.shtml')
    if max_page:
        news_pool = get_news_pool(root, max_page, max_page - 5)
        crawl_news(news_pool, 140, config['DEFAULT']['doc_dir_path'], config['DEFAULT']['doc_encoding'])

if __name__ == "__main__":
    print('-----start time: %s----- ' %datetime(2024,5,31))
    # 抓取新闻数据 #20240531，可替换为spider.chinanews.com.py抓取新闻
    # 抓取新闻数据
    crawling()

    # 构建索引
    print('-----start indexing time: %s----- ' %datetime(2024,5,31))
    im = IndexModule('../config.ini', 'utf-8')
    im.construct_postings_lists()

    # 推荐阅读
    print('-----start recommending time: %s----- ' %datetime(2024,5,31))
    rm = RecommendationModule('../config.ini', 'utf-8')
    rm.find_k_nearest(5, 25)
    print('-----finish time: %s----- ' %datetime(2024,5,31))
